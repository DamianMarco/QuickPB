<?php $__env->startSection('content'); ?>
<table class="body-wrap" bgcolor="#f6f6f6">
  <tr>
    <td></td>
    <td class="container" bgcolor="#FFFFFF">

      <!-- content -->
      <div class="content">
      <table>
        <tr>
          <td>
          	<h1>CONTACTO QUICKPOBOX</h1>
            <p>El señor(a) <?php echo e($name); ?>,</p>
            
            <p>Ha enviado el siguiente mensaje/comentario desde <a href="www.quickpobox.com" targer="_blank">QUICKPOBOX</a> </p>
            <h4>MENSAJE/COMENTARIO</h4>
            <p><?php echo e($mensaje); ?></p>
            <p></p>
            <p>Correo de contacto: <?php echo e($email); ?>.</p>
            <p><!--a href="http://twitter.com/leemunroe">Follow @leemunroe  on Twitter</a--></p>
          </td>
        </tr>
      </table>
      </div>
      <!-- /content -->
      
    </td>
    <td></td>
  </tr>
</table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('emails.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>