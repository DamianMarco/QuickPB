<?php $__env->startSection('title', 'Nosotros'); ?>

<?php $__env->startSection('content'); ?>
<div id="subhead_container">    
	<div class="row">
		<div class="panel panel-default">
  			<div class="panel-heading">NOSOTROS</div>
  			<div class="panel-body">
    			QUICK PO BOX es una empresa 100% regiomontana que se dedica a la logística de importación, distribución y envío de mercancía. 

    			Nuestro principal objetivo es hacer que por un solo medio y con una atención totalmente personalizada nuestros clientes puedan importar mercancía y ponerla en la puerta de su casa con un solo click.
  			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>