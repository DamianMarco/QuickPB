
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">

			/*logo*/
			/*////////////////////////////////////////////////////////////////////////////////////////////*/
			#logo2 {
				margin: 0px 0px 0px 0px;
				float: left;
			}

			body{
				margin: 0px 0px 0px 0px;

			}


			#logo2{
				text-decoration: none;
				font-size: 42px;
				letter-spacing: -1pt;
				font-weight: bold;
				font-family:arial, "Times New Roman", Times, serif;
				text-align: left;
				line-height: 57px;
				padding-left: 0px;
				clear: both;
				margin-left: 10px;
			}

			#logo2 a, #slogan{
				color: #fd7800;
			}

			.contenido{
				margin-left: 10px;
				clear: both;
			}

			a:link { color: #000000; text-decoration: none}
	</style>
</head>
<body>

	<div style="background-color: #fd7800; width: 100%; height: 4px; margin: 0px:">		
	</div>
	
	<div id="logo2"><a href="http://localhost:81/quickpb/public/index.php" title="QuickPOBox">QuickPOBox</a>
	</div><!--logo end-->
		<br/>  
	
	<div class="contenido">
	<h2>bienvenido!</h2>
		<h3><?php echo e($name); ?></h3>
	</div>
	





</body>
</html>

