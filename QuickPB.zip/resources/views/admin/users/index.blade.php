@extends('admin.templates.main')
@section('title', 'Usuarios')

@section('content')
<div id="subhead_container">
		
		<div class="row">

		<div class="twelve columns">
		
		<h1>Mi cuenta</h1>
			
			</div>	
			
	</div>
</div>

@endsection
