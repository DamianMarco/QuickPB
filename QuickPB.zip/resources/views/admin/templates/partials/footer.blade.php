<div id="footer-container">

	<!--footer container--><div class="row">
		
		<div class="twelve columns" id="footer-widget">
			
			<div id="footer-bar1" class="four columns">
					<ul class="xoxo">
						<li id="text-2" class="widget-container widget_text"><h3 class="widget-title">QuickPoBox</h3>			<div class="textwidget"><ul>
<li><a href="http://www.quickpobox.com/nosotros/">Nosotros</a> </li>
<li><a href="http://www.quickpobox.com/ubicacion/nosotros/">Ubicación</a></li>
</ul></div>
		</li>					</ul>
					
					
</div><!--footer 1 end-->



<div id="footer-bar2" class="four columns">
					<ul class="xoxo">
						<li id="text-3" class="widget-container widget_text"><h3 class="widget-title">Información</h3>			<div class="textwidget"><ul>
<li><a href="http://www.quickpobox.com/preguntas-frecuentes/">Preguntas frecuentes</a></li>
<li><a href="http://www.quickpobox.com/envios/">Envios</a></li>
<li><a href="http://www.quickpobox.com/contacto/">Contacto</a></li>
</ul>
</div>
		</li>					</ul>
</div><!--footer 2 end-->


<div id="footer-bar3" class="four columns">
					<ul class="xoxo">
						<li id="text-4" class="widget-container widget_text"><h3 class="widget-title">Politicas</h3>			<div class="textwidget"><p><a href="http://www.quickpobox.com/condiciones-de-uso/">Condiciones de uso</a></p>
<a href="http://www.quickpobox.com/proteccion-de-la-informacion/">Protección de la información</a>
</div>
		</li>					</ul>
					
	</div><!--footer 3 end-->			
			</div><!--footer widget end-->
			
		</div><!-- footer container-->
					
	</div>

<div id="footer-info">

				<!--footer container-->
	<div class="row">
				
		<div class="twelve columns">					
			
			<div id="copyright">Copyright 2016 QuickPoBox </div>
			
			<div class="scroll-top"><a href="#scroll-top" title="scroll to top">↑</a></div>	
			</div>	
		</div>		
</div>
