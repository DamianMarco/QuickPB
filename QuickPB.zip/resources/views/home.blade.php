

@extends('admin.templates.main')
@section('title', 'Bienvenido')

@section('content')
<div id="subhead_container">
        
    <div class="row">

        <div class="jumbotron">
          <h1>Bienvenido!!</h1>
          <p>...</p>
          <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a></p>
        </div>
            
    </div>
</div>


@endsection